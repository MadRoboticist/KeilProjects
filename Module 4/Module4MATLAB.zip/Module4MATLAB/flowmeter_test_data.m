buf = fileread( 'ECEN5003Data7.txt' ) ;
% - Keep only relevant characters.
buf = buf(buf>47) ;
% - Cast to double (makes the following faster).
buf = buf + 0 ;
% - Map '0'-'9' to 0-9 and 'A'-'F' to 10-15.
idNum = buf < 58 ;
buf(idNum)  = buf(idNum)  - 48 ; 
buf(~idNum) = buf(~idNum) - 55 ; 
% - Build dec value from components and shape as rectangular array.
img = reshape( [16^3, 16^2, 16, 1] * reshape(buf, 4, []), 1000, [] ) ;
t= [0:0.0001:1000*0.0001-0.0001] ;
ts = timeseries(img, t) ;
plot(ts) ;
clear buf idNum img;
save flowmeter_data -v7.3 ts ;